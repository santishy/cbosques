<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class QuoteResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
          'description' => $this->description,
          //'qty' => number_format($this->qty,2),
          'qty' => $this->qty,
          'archive' => explode('/',$this->archive)[1], // Aquí corto el nombre del archivo de la ruta
          'status' => $this->status,
          'id' => $this->id,
          'iva' => $this->iva(),
          'total' => $this->total(),
          'cycle_id' => $this->cycle_id,
          'item_id' => $this->item_id,
          'department_id' => $this->department_id,
        ];
    }
}
