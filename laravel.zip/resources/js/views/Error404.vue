<template>
  <div class="row">
    <div class="col-md-4">
      <h2>Esta página no existe</h2>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
</style>
