<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/code/budgets/resources/views/vendor/mail/text/table.blade.php ENDPATH**/ ?>