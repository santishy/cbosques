<?php $__env->startComponent('mail::message'); ?>
# cotización <?php echo e($quotation->status); ?>


<?php if(isset($quotation->message)): ?>
  <?php echo e($quotation->message); ?>

<?php endif; ?>

<?php $__env->startComponent('mail::button', ['url' => 'google.com','color' => 'primary']); ?>
Ir
<?php echo $__env->renderComponent(); ?>

Gracias por su atención,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/code/budgets/resources/views/emails/quotations/updated.blade.php ENDPATH**/ ?>