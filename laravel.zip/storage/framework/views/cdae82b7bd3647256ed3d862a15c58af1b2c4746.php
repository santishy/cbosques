[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/vagrant/code/budgets/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>