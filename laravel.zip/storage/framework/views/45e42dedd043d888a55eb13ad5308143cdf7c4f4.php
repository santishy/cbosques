<?php $__env->startComponent('mail::message'); ?>
# COTIZACIÓN CREADA

<b><?php echo e($notifiable->name); ?></b> a creado una nueva cotización:

<?php $__env->startComponent('mail::table'); ?>
  |DESCRIPCIÓN|COSTO|IVA|TOTAL|
  |:-----------:|:--------------------:|:-------------------:|:-------------------:|
  |<?php echo e($quotation->description); ?>|<?php echo e($quotation->qty); ?>|<?php echo e($quotation->iva()); ?>|<?php echo e($quotation->total()); ?>

<?php echo $__env->renderComponent(); ?>
<p>Para responder a esta cotización, verifique la notificación en el sistema</p>
<?php $__env->startComponent('mail::button', ['url' => url('/'),'color' => 'primary']); ?>
Ir
<?php echo $__env->renderComponent(); ?>

Gracias por su atención,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/code/budgets/resources/views/emails/quotations/created.blade.php ENDPATH**/ ?>