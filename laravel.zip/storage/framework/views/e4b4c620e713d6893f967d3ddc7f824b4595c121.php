<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH /home/vagrant/code/budgets/resources/views/vendor/mail/html/table.blade.php ENDPATH**/ ?>