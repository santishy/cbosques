<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/code/budgets/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>